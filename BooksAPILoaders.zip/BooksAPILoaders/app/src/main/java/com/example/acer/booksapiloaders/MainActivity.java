package com.example.acer.booksapiloaders;

import android.support.v4.app.LoaderManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String>{
    EditText titletext;
    TextView textView,author;
    ArrayList <Books> list;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        titletext=(EditText)findViewById(R.id.edt1);
        recyclerView=(RecyclerView)findViewById(R.id.recv);

    }

    public void search(View view) {
        String string=titletext.getText().toString();
        Bundle bundle=new Bundle();
        bundle.putString("data",string);
        getSupportLoaderManager().restartLoader(1,bundle,MainActivity.this);
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String data=args.getString("data");

        return new MyAsc(this,data);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        list=new ArrayList<Books>();
        try {
            JSONObject object=new JSONObject(data);
            JSONArray array=object.getJSONArray("items");
            StringBuilder builder=new StringBuilder();
            String publisher=null;
            String publishedDate=null;
            String imageLink=null;
            String title=null;
            for(int i=0;i<array.length();i++){
                JSONObject obj1=array.getJSONObject(i);
                JSONObject volume=obj1.getJSONObject("volumeInfo");
                title=volume.getString("title");
                publisher=volume.getString("publisher");
                publishedDate=volume.getString("publishedDate");
                JSONObject imgObject=volume.getJSONObject("imageLinks");
                imageLink=imgObject.getString("thumbnail");

                String author=volume.getString("authors");
                builder.append(title+author);
                Books books=new Books(title,publisher,publishedDate,imageLink);
                list.add(books);
                books.setTitle(title);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        MyAdapter adapter=new MyAdapter(this,list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);


    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
