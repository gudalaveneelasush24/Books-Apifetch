package com.example.acer.booksapiloaders;

import android.content.ContentValues;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {
    ImageView img;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        textView=(TextView)findViewById(R.id.textview);
        img=(ImageView)findViewById(R.id.img);

        String title=getIntent().getStringExtra("t");
        String publisher=getIntent().getStringExtra("p");
        String publishedDate=getIntent().getStringExtra("pd");
        String link=getIntent().getStringExtra("i");
        Picasso.with(this).load(link).into(img);


        textView.setText(title+"\n"+publisher+"\n"+publishedDate);


    }

    public void content(View view) {
        String details = textView.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.col_1, details);
        Uri u = getContentResolver().insert(MyContentProvider.ContentUri, cv);
        if (u != null) {

            Toast.makeText(this,u.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}
