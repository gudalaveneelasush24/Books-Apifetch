package com.example.acer.booksapiloaders;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewInfo>{
    Context ct;
    ArrayList<Books> list;
    public MyAdapter(MainActivity mainActivity, ArrayList<Books> list) {
        ct=mainActivity;
        this.list=list;
    }

    @NonNull
    @Override
    public MyViewInfo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //How to display Data
        View v= LayoutInflater.from(ct).inflate(R.layout.row,parent,false);
        return new MyViewInfo(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewInfo holder, int position) {
        holder.tv.setText(list.get(position).getTitle());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class MyViewInfo extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tv;
        public MyViewInfo(View itemView) {
            super(itemView);
            tv=itemView.findViewById(R.id.Text);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int pos=getAdapterPosition();
            Toast.makeText(ct, " "+pos, Toast.LENGTH_SHORT).show();
            Intent i=new Intent(ct,DetailsActivity.class);
            i.putExtra("t",list.get(pos).getTitle());
            i.putExtra("p",list.get(pos).getPublisher());
            i.putExtra("pd",list.get(pos).getPublishedData());
            i.putExtra("i",list.get(pos).getImageLink());
            ct.startActivity(i);
        }
    }
}
