package com.example.acer.booksapiloaders;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    public static final String Table_Name = "Books";
    public static final String Db_Name = "booksDb";
    public static final String col_1 = "details";
    public static final String CreateTable="create table "+Table_Name+"(" +
            col_1+ "text);";

    public DbHelper(Context context) {
        super(context, Db_Name,null,1);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CreateTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists "+Table_Name);
        onCreate(db);

    }
}
