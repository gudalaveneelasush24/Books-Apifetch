package com.example.acer.booksapiloaders;

import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

class MyAsc extends AsyncTaskLoader<String> {
    String Mydata;
    public static final String Url="https://www.googleapis.com/books/v1/volumes?";
    public static final String Qurey_param="q";
    public static final String Max_Results="max";
    public static final String PrintType="printtype";

    public MyAsc(MainActivity mainActivity, String data) {
        super(mainActivity);
        Mydata=data;
        Log.d("data",Mydata);
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    @Nullable
    @Override
    public String loadInBackground() {
        Uri u=Uri.parse(Url).buildUpon().appendQueryParameter(Qurey_param,Mydata).
                appendQueryParameter(Max_Results,"10")
                .appendQueryParameter(PrintType,"books").build();
        try {
            URL url=new URL(u.toString());
            HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            InputStream in=urlConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(in));
            StringBuilder builder=new StringBuilder();
            String line="";
            while ((line=bufferedReader.readLine())!=null){
                builder.append(line);
            }
            return builder.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
