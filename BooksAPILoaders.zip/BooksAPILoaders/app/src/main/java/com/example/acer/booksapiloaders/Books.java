package com.example.acer.booksapiloaders;
//pojo class

public class Books {
    public String Title;
    public String Publisher;
    public String PublishedDate;
    public String ImageLink;
    public Books(){}

    public Books(String title, String publisher, String publishedDate, String imageLink) {
        Title = title;
        Publisher = publisher;
        PublishedDate = publishedDate;
        ImageLink = imageLink;
    }

    public String getTitle() {
        return Title;
    }

    public String getPublisher() {
        return Publisher;
    }

    public String getPublishedData() {
        return PublishedDate;
    }

    public String getImageLink() {
        return ImageLink;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setPublisher(String publisher) {
        Publisher = publisher;
    }

    public void setPublishedDate(String publishedDate) {
        PublishedDate = publishedDate;
    }

    public void setImageLink(String imageLink) {
        ImageLink = imageLink;
    }
}
